import SwiftUI
import SwiftData

struct ContentView: View {
    var body: some View {
        TabView {
            LandingView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            
            RandomRecipesView()
                .tabItem {
                    Label("Recipes", systemImage: "fork.knife")
                }
        }
    }
}

#Preview {
    ContentView()
} 
