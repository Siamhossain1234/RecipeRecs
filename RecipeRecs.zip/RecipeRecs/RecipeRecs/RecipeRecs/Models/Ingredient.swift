import Foundation

struct Ingredient: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var isSelected: Bool
    var image: String?
    
    init(id: UUID = UUID(), name: String, isSelected: Bool = false, image: String? = nil) {
        self.id = id
        self.name = name
        self.isSelected = isSelected
        self.image = image
    }
} 
