import Foundation

struct Recipe: Identifiable, Codable {
    let id: Int
    let title: String
    let image: String
    let imageType: String?
    let usedIngredientCount: Int?
    let missedIngredientCount: Int?
    let missedIngredients: [RecipeIngredient]?
    let usedIngredients: [RecipeIngredient]?
    let unusedIngredients: [RecipeIngredient]?
    let likes: Int?
    let readyInMinutes: Int?
    let servings: Int?
    let sourceUrl: String?
    let summary: String?
    let instructions: String?
}

struct RecipeIngredient: Codable, Identifiable {
    let id: Int
    let amount: Double
    let unit: String
    let unitLong: String
    let unitShort: String
    let aisle: String
    let name: String
    let original: String
    let originalName: String
    let meta: [String]
    let image: String
} 