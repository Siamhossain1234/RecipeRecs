import SwiftUI

struct AddIngredientView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var viewModel: IngredientsViewModel
    @State private var ingredientName = ""
    
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Ingredient Name", text: $ingredientName)
                }
            }
            .navigationTitle("Add Ingredient")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") {
                        if !ingredientName.isEmpty {
                            dismiss()
                        }
                    }
                    .disabled(ingredientName.isEmpty)
                }
            }
        }
    }
}

#Preview {
    AddIngredientView(viewModel: IngredientsViewModel())
} 
