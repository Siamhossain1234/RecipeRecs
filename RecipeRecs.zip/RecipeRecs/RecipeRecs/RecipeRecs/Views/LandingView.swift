import SwiftUI

struct LandingView: View {
    @StateObject private var viewModel = IngredientsViewModel()
    @State private var showingRecipes = false
    
    var body: some View {
        NavigationStack {
            LandingContentView(
                viewModel: viewModel,
                showingRecipes: $showingRecipes
            )
            .navigationTitle("RecipeRecs")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

private struct LandingContentView: View {
    @ObservedObject var viewModel: IngredientsViewModel
    @Binding var showingRecipes: Bool
    
    var body: some View {
        ZStack(alignment: .bottom) {
            ScrollView {
                VStack(spacing: 20) {
                    SearchBar(text: $viewModel.searchText)
                        .padding(.horizontal)
                    
                    if !viewModel.userIngredients.isEmpty {
                        UserIngredientsSection(viewModel: viewModel)
                    }
                    
                    AvailableIngredientsSection(viewModel: viewModel)
                    
                    if !viewModel.userIngredients.isEmpty {
                        Color.clear
                            .frame(height: 80)
                    }
                }
            }
            
            if !viewModel.userIngredients.isEmpty {
                FindRecipesButton(showingRecipes: $showingRecipes)
            }
        }
        .sheet(isPresented: $showingRecipes) {
            NavigationStack {
                RecipeListView(viewModel: viewModel)
                    .navigationTitle("Recipes")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button("Done") {
                                showingRecipes = false
                            }
                        }
                    }
            }
            .task {
                await viewModel.searchRecipes()
            }
        }
    }
}

private struct UserIngredientsSection: View {
    @ObservedObject var viewModel: IngredientsViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Your Ingredients")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.horizontal)
            
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 12) {
                    ForEach(viewModel.userIngredients) { ingredient in
                        UserIngredientCard(ingredient: ingredient) {
                            viewModel.toggleIngredient(ingredient)
                        } onRemove: {
                            viewModel.removeFromUserIngredients(ingredient)
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

private struct AvailableIngredientsSection: View {
    @ObservedObject var viewModel: IngredientsViewModel
    
    private let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Ingredients")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.horizontal)
            
            LazyVGrid(columns: columns, spacing: 16) {
                ForEach(viewModel.filteredPredefinedIngredients) { ingredient in
                    PredefinedIngredientCard(
                        ingredient: ingredient,
                        viewModel: viewModel
                    )
                }
            }
            .padding(.horizontal)
        }
    }
}

private struct FindRecipesButton: View {
    @Binding var showingRecipes: Bool
    
    var body: some View {
        VStack {
            Divider()
            Button(action: {
                showingRecipes = true
            }) {
                Text("Find Recipes")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(12)
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(Color(UIColor.systemBackground))
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("Search ingredients", text: $text)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }
    }
}

struct UserIngredientCard: View {
    let ingredient: Ingredient
    let onTap: () -> Void
    let onRemove: () -> Void
    
    var body: some View {
        VStack {
            ZStack(alignment: .topTrailing) {
                RoundedRectangle(cornerRadius: 12)
                    .fill(ingredient.isSelected ? Color.blue.opacity(0.1) : Color.gray.opacity(0.1))
                
                Button(action: onRemove) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.red)
                        .padding(8)
                }
            }
            .frame(width: 100, height: 120)
            .overlay(
                VStack {
                    if let imageName = ingredient.image {
                        Image(systemName: imageName)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 40)
                            .foregroundColor(.green)
                    } else {
                        Image(systemName: "leaf.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 40)
                            .foregroundColor(.green)
                    }
                    
                    Text(ingredient.name)
                        .font(.caption)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 4)
                }
            )
            .onTapGesture(perform: onTap)
        }
    }
}

struct PredefinedIngredientCard: View {
    let ingredient: Ingredient
    @ObservedObject var viewModel: IngredientsViewModel
    
    var body: some View {
        VStack {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gray.opacity(0.1))
                
                VStack {
                    if let imageName = ingredient.image {
                        Image(systemName: imageName)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 40)
                            .foregroundColor(.green)
                    } else {
                        Image(systemName: "leaf.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 40)
                            .foregroundColor(.green)
                    }
                    
                    Text(ingredient.name)
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                    
                    Button(action: {
                        viewModel.addToUserIngredients(ingredient)
                    }) {
                        HStack {
                            Image(systemName: viewModel.isIngredientInUserList(ingredient) ? "checkmark" : "plus")
                            Text(viewModel.isIngredientInUserList(ingredient) ? "Added" : "Add")
                        }
                        .font(.caption)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(viewModel.isIngredientInUserList(ingredient) ? Color.green : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                    .disabled(viewModel.isIngredientInUserList(ingredient))
                    .padding(.top, 4)
                }
                .padding(8)
            }
            .frame(height: 150)
        }
    }
}

#Preview {
    LandingView()
} 
