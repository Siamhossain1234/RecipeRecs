import SwiftUI

struct RecipeListView: View {
    @ObservedObject var viewModel: IngredientsViewModel
    
    var body: some View {
        List(viewModel.recipes) { recipe in
            NavigationLink(destination: RecipeDetailView(recipe: recipe)) {
                RecipeRow(recipe: recipe)
            }
        }
        .overlay {
            if viewModel.isLoading {
                ProgressView()
            } else if let error = viewModel.error {
                Text(error)
                    .foregroundColor(.red)
                    .padding()
            } else if viewModel.recipes.isEmpty {
                Text("No recipes found")
                    .foregroundColor(.gray)
                    .padding()
            }
        }
    }
}

struct RecipeRow: View {
    let recipe: Recipe
    
    var body: some View {
        HStack(spacing: 12) {
            AsyncImage(url: URL(string: recipe.image)) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } placeholder: {
                Color.gray.opacity(0.2)
            }
            .frame(width: 100, height: 100)
            .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(recipe.title)
                    .font(.headline)
                    .lineLimit(2)
                
                if let readyInMinutes = recipe.readyInMinutes {
                    Text("Ready in \(readyInMinutes) minutes")
                        .font(.caption)
                        .foregroundColor(.blue)
                }
                
                if let servings = recipe.servings {
                    Text("Serves \(servings)")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                
                if let usedCount = recipe.usedIngredientCount, let missedCount = recipe.missedIngredientCount {
                    HStack {
                        Text("\(usedCount) ingredients used")
                            .font(.caption)
                            .foregroundColor(.green)
                        
                        if missedCount > 0 {
                            Text("•")
                                .foregroundColor(.gray)
                            Text("\(missedCount) missing")
                                .font(.caption)
                                .foregroundColor(.orange)
                        }
                    }
                }
            }
        }
        .padding(.vertical, 8)
    }
}

#Preview {
    RecipeListView(viewModel: IngredientsViewModel())
} 
