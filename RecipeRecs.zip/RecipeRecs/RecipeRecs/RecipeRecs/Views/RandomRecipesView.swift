import SwiftUI

struct RandomRecipesView: View {
    @StateObject private var viewModel = RandomRecipesViewModel()
    
    var body: some View {
        NavigationStack {
            List(viewModel.recipes) { recipe in
                NavigationLink(destination: RecipeDetailView(recipe: recipe)) {
                    RecipeRow(recipe: recipe)
                }
            }
            .overlay {
                if viewModel.isLoading {
                    ProgressView()
                } else if let error = viewModel.error {
                    Text(error)
                        .foregroundColor(.red)
                        .padding()
                } else if viewModel.recipes.isEmpty {
                    Text("No recipes found")
                        .foregroundColor(.gray)
                        .padding()
                }
            }
            .navigationTitle("Random Recipes")
            .navigationBarTitleDisplayMode(.inline)
            .refreshable {
                await viewModel.loadRandomRecipes()
            }
        }
        .task {
            await viewModel.loadRandomRecipes()
        }
    }
}

#Preview {
    RandomRecipesView()
} 