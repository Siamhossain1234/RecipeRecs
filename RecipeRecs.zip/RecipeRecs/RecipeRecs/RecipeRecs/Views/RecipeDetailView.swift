import SwiftUI

struct RecipeDetailView: View {
    let recipe: Recipe
    @State private var detailedRecipe: Recipe?
    @State private var isLoading = false
    @State private var error: String?
    
    private let recipeService = RecipeService()
    
    var body: some View {
        ScrollView {
            if isLoading {
                ProgressView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let error = error {
                Text(error)
                    .foregroundColor(.red)
                    .padding()
            } else {
                VStack(alignment: .leading, spacing: 16) {
                    // Recipe Image
                    AsyncImage(url: URL(string: recipe.image)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    } placeholder: {
                        Color.gray.opacity(0.2)
                    }
                    .frame(height: 250)
                    .clipped()
                    
                    VStack(alignment: .leading, spacing: 16) {
                        // Title and Basic Info
                        VStack(alignment: .leading, spacing: 8) {
                            Text(recipe.title)
                                .font(.title)
                                .fontWeight(.bold)
                            
                            HStack(spacing: 16) {
                                if let readyInMinutes = detailedRecipe?.readyInMinutes {
                                    Label("\(readyInMinutes) min", systemImage: "clock")
                                }
                                if let servings = detailedRecipe?.servings {
                                    Label("\(servings) servings", systemImage: "person.2")
                                }
                            }
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        }
                        
                        // Ingredients Section
                        if let usedIngredients = recipe.usedIngredients, !usedIngredients.isEmpty {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Ingredients You Have")
                                    .font(.headline)
                                
                                ForEach(usedIngredients) { ingredient in
                                    HStack {
                                        AsyncImage(url: URL(string: ingredient.image)) { image in
                                            image
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                        } placeholder: {
                                            Color.gray.opacity(0.2)
                                        }
                                        .frame(width: 40, height: 40)
                                        .cornerRadius(4)
                                        
                                        Text(ingredient.original)
                                            .font(.subheadline)
                                    }
                                }
                            }
                        }
                        
                        if let missedIngredients = recipe.missedIngredients, !missedIngredients.isEmpty {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Missing Ingredients")
                                    .font(.headline)
                                
                                ForEach(missedIngredients) { ingredient in
                                    HStack {
                                        AsyncImage(url: URL(string: ingredient.image)) { image in
                                            image
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                        } placeholder: {
                                            Color.gray.opacity(0.2)
                                        }
                                        .frame(width: 40, height: 40)
                                        .cornerRadius(4)
                                        
                                        Text(ingredient.original)
                                            .font(.subheadline)
                                    }
                                }
                            }
                        }
                        
                        if let summary = detailedRecipe?.summary {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Summary")
                                    .font(.headline)
                                
                                Text(summary.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression))
                                    .font(.body)
                            }
                        }
                        
                        if let instructions = detailedRecipe?.instructions {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Instructions")
                                    .font(.headline)
                                
                                Text(instructions.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression))
                                    .font(.body)
                            }
                        }
                    }
                    .padding()
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .task {
            await loadRecipeDetails()
        }
    }
    
    private func loadRecipeDetails() async {
        isLoading = true
        error = nil
        
        do {
            detailedRecipe = try await recipeService.getRecipeDetails(id: recipe.id)
        } catch {
            self.error = error.localizedDescription
        }
        
        isLoading = false
    }
} 
