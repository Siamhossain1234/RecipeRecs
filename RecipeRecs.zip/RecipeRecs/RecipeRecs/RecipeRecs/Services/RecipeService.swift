import Foundation

class RecipeService {
    private let apiKey = "a0a6124704b64ceda34eb2cf41b7b360"
    
    func findRecipesByIngredients(ingredients: [String]) async throws -> [Recipe] {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "api.spoonacular.com"
        components.path = "/recipes/findByIngredients"
        //formatting
        let ingredientsList = ingredients
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .joined(separator: ",+")
        
        components.queryItems = [
            URLQueryItem(name: "apiKey", value: apiKey),
            URLQueryItem(name: "ingredients", value: ingredientsList),
            URLQueryItem(name: "number", value: "6"),
            URLQueryItem(name: "ranking", value: "2"),
            URLQueryItem(name: "ignorePantry", value: "true")
        ]
        
        guard let url = components.url else {
            throw URLError(.badURL)
        }
        
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw URLError(.badServerResponse)
        }
        
        return try JSONDecoder().decode([Recipe].self, from: data)
    }
    
    func getRecipeDetails(id: Int) async throws -> Recipe {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "api.spoonacular.com"
        components.path = "/recipes/\(id)/information"
        
        components.queryItems = [
            URLQueryItem(name: "apiKey", value: apiKey),
            URLQueryItem(name: "addRecipeInformation", value: "true"),
            URLQueryItem(name: "fillIngredients", value: "true"),
            URLQueryItem(name: "instructionsRequired", value: "true")
        ]
        
        guard let url = components.url else {
            throw URLError(.badURL)
        }
        
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw URLError(.badServerResponse)
        }
        
        return try JSONDecoder().decode(Recipe.self, from: data)
    }
    
    func getRandomRecipes() async throws -> [Recipe] {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "api.spoonacular.com"
        components.path = "/recipes/random"
        
        components.queryItems = [
            URLQueryItem(name: "apiKey", value: apiKey),
            URLQueryItem(name: "number", value: "6"),
            URLQueryItem(name: "tags", value: "main course,dinner"),
            URLQueryItem(name: "addRecipeInformation", value: "true"),
            URLQueryItem(name: "fillIngredients", value: "true"),
            URLQueryItem(name: "instructionsRequired", value: "true")
        ]
        
        guard let url = components.url else {
            throw URLError(.badURL)
        }
        
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw URLError(.badServerResponse)
        }
        let randomResponse = try JSONDecoder().decode(RandomRecipesResponse.self, from: data)
        return randomResponse.recipes
    }
}

struct RandomRecipesResponse: Codable {
    let recipes: [Recipe]
} 
