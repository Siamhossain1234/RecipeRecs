import Foundation
import Combine

@MainActor
class RandomRecipesViewModel: ObservableObject {
    @Published var recipes: [Recipe] = []
    @Published var isLoading: Bool = false
    @Published var error: String?
    
    private let recipeService = RecipeService()
    
    func loadRandomRecipes() async {
        isLoading = true
        error = nil
        
        do {
            recipes = try await recipeService.getRandomRecipes()
        } catch {
            self.error = error.localizedDescription
        }
        
        isLoading = false
    }
} 