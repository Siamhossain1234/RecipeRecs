import Foundation
import Combine
import SwiftUI

@MainActor
class IngredientsViewModel: ObservableObject {
    @Published var userIngredients: [Ingredient] = []
    @Published var predefinedIngredients: [Ingredient] = []
    @Published var searchText: String = ""
    @Published var filteredPredefinedIngredients: [Ingredient] = []
    @Published var recipes: [Recipe] = []
    @Published var isLoading: Bool = false
    @Published var error: String?
    
    @AppStorage("savedIngredients") private var savedIngredientsData: Data?
    
    private var cancellables = Set<AnyCancellable>()
    private let recipeService = RecipeService()
    
    init() {
        setupPredefinedIngredients()
        loadSavedIngredients()
        setupSubscriptions()
    }
    
    private func setupPredefinedIngredients() {
        predefinedIngredients = [
            // Vegetables
            Ingredient(name: "Tomatoes", image: "leaf.fill"),
            Ingredient(name: "Onions", image: "circle.fill"),
            Ingredient(name: "Garlic", image: "circle.fill"),
            Ingredient(name: "Bell Peppers", image: "leaf.fill"),
            Ingredient(name: "Carrots", image: "carrot.fill"),
            Ingredient(name: "Potatoes", image: "circle.fill"),
            Ingredient(name: "Broccoli", image: "leaf.fill"),
            Ingredient(name: "Cauliflower", image: "leaf.fill"),
            Ingredient(name: "Spinach", image: "leaf.fill"),
            Ingredient(name: "Kale", image: "leaf.fill"),
            Ingredient(name: "Cucumber", image: "leaf.fill"),
            Ingredient(name: "Zucchini", image: "leaf.fill"),
            Ingredient(name: "Eggplant", image: "leaf.fill"),
            Ingredient(name: "Mushrooms", image: "circle.fill"),
            Ingredient(name: "Corn", image: "circle.fill"),
            Ingredient(name: "Green Beans", image: "leaf.fill"),
            Ingredient(name: "Asparagus", image: "leaf.fill"),
            Ingredient(name: "Sweet Potato", image: "circle.fill"),
            
            // Proteins
            Ingredient(name: "Chicken", image: "diamond.fill"),
            Ingredient(name: "Beef", image: "diamond.fill"),
            Ingredient(name: "Pork", image: "diamond.fill"),
            Ingredient(name: "Fish", image: "diamond.fill"),
            Ingredient(name: "Shrimp", image: "diamond.fill"),
            Ingredient(name: "Tofu", image: "square.fill"),
            Ingredient(name: "Eggs", image: "circle.fill"),
            Ingredient(name: "Turkey", image: "diamond.fill"),
            Ingredient(name: "Lamb", image: "diamond.fill"),
            Ingredient(name: "Salmon", image: "diamond.fill"),
            Ingredient(name: "Tuna", image: "diamond.fill"),
            
            // Grains and Starches
            Ingredient(name: "Rice", image: "circle.fill"),
            Ingredient(name: "Pasta", image: "circle.fill"),
            Ingredient(name: "Bread", image: "square.fill"),
            Ingredient(name: "Quinoa", image: "circle.fill"),
            Ingredient(name: "Couscous", image: "circle.fill"),
            Ingredient(name: "Barley", image: "circle.fill"),
            Ingredient(name: "Oats", image: "circle.fill"),
            Ingredient(name: "Flour", image: "circle.fill"),
            
            // Dairy and Alternatives
            Ingredient(name: "Milk", image: "drop.fill"),
            Ingredient(name: "Cheese", image: "square.fill"),
            Ingredient(name: "Butter", image: "square.fill"),
            Ingredient(name: "Yogurt", image: "drop.fill"),
            Ingredient(name: "Cream", image: "drop.fill"),
            Ingredient(name: "Sour Cream", image: "drop.fill"),
            Ingredient(name: "Almond Milk", image: "drop.fill"),
            Ingredient(name: "Soy Milk", image: "drop.fill"),
            
            // Oils and Condiments
            Ingredient(name: "Olive Oil", image: "drop.fill"),
            Ingredient(name: "Vegetable Oil", image: "drop.fill"),
            Ingredient(name: "Salt", image: "circle.fill"),
            Ingredient(name: "Black Pepper", image: "circle.fill"),
            Ingredient(name: "Sugar", image: "circle.fill"),
            Ingredient(name: "Honey", image: "drop.fill"),
            Ingredient(name: "Vinegar", image: "drop.fill"),
            Ingredient(name: "Soy Sauce", image: "drop.fill"),
            Ingredient(name: "Mustard", image: "circle.fill"),
            Ingredient(name: "Ketchup", image: "circle.fill"),
            
            // Herbs and Spices
            Ingredient(name: "Basil", image: "leaf.fill"),
            Ingredient(name: "Thyme", image: "leaf.fill"),
            Ingredient(name: "Rosemary", image: "leaf.fill"),
            Ingredient(name: "Oregano", image: "leaf.fill"),
            Ingredient(name: "Cinnamon", image: "sparkles"),
            Ingredient(name: "Cumin", image: "sparkles"),
            Ingredient(name: "Paprika", image: "sparkles"),
            Ingredient(name: "Ginger", image: "sparkles"),
            Ingredient(name: "Turmeric", image: "sparkles"),
            Ingredient(name: "Cayenne", image: "flame.fill"),
            
            // Fruits
            Ingredient(name: "Apples", image: "apple.logo"),
            Ingredient(name: "Bananas", image: "circle.fill"),
            Ingredient(name: "Oranges", image: "circle.fill"),
            Ingredient(name: "Lemons", image: "circle.fill"),
            Ingredient(name: "Limes", image: "circle.fill"),
            Ingredient(name: "Berries", image: "circle.fill"),
            Ingredient(name: "Grapes", image: "circle.fill"),
            Ingredient(name: "Pineapple", image: "circle.fill"),
            Ingredient(name: "Mango", image: "circle.fill"),
            Ingredient(name: "Avocado", image: "circle.fill")
        ]
        filteredPredefinedIngredients = predefinedIngredients
    }
    
    private func setupSubscriptions() {
        $searchText
            .debounce(for: .milliseconds(300), scheduler: DispatchQueue.main)
            .sink { [weak self] searchText in
                self?.filterIngredients(searchText: searchText)
            }
            .store(in: &cancellables)
        
        $userIngredients
            .sink { [weak self] ingredients in
                self?.saveIngredients(ingredients)
            }
            .store(in: &cancellables)
    }
    
    private func filterIngredients(searchText: String) {
        if searchText.isEmpty {
            filteredPredefinedIngredients = predefinedIngredients
        } else {
            filteredPredefinedIngredients = predefinedIngredients.filter { 
                $0.name.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    func addToUserIngredients(_ ingredient: Ingredient) {
        guard !userIngredients.contains(where: { $0.name == ingredient.name }) else { return }
        userIngredients.append(ingredient)
    }
    
    func removeFromUserIngredients(_ ingredient: Ingredient) {
        userIngredients.removeAll { $0.id == ingredient.id }
    }
    
    func toggleIngredient(_ ingredient: Ingredient) {
        if let index = userIngredients.firstIndex(where: { $0.id == ingredient.id }) {
            userIngredients[index].isSelected.toggle()
        }
    }
    
    private func saveIngredients(_ ingredients: [Ingredient]) {
        do {
            let data = try JSONEncoder().encode(ingredients)
            savedIngredientsData = data
        } catch {
            print("Error saving ingredients: \(error)")
        }
    }
    
    private func loadSavedIngredients() {
        guard let data = savedIngredientsData else { return }
        do {
            userIngredients = try JSONDecoder().decode([Ingredient].self, from: data)
        } catch {
            print("Error loading ingredients: \(error)")
        }
    }
    
    func searchRecipes() async {
        guard !userIngredients.isEmpty else { return }
        
        isLoading = true
        error = nil
        
        do {
            let ingredientNames = userIngredients.map { $0.name }
            recipes = try await recipeService.findRecipesByIngredients(ingredients: ingredientNames)
        } catch {
            self.error = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func isIngredientInUserList(_ ingredient: Ingredient) -> Bool {
        return userIngredients.contains(where: { $0.name == ingredient.name })
    }
    
}
