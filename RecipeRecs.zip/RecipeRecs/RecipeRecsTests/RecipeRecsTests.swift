//
//  RecipeRecsTests.swift
//  RecipeRecsTests
//
//  Created by Siam Hossain on 3/21/25.
//

import Testing
@testable import RecipeRecs

struct RecipeRecsTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
